<html>
<style>
p {
  color: red;
}
div {
  border: 1px solid black;
  background-color: Coral;
  padding-top: 50px;
  padding-right: 30px;
  padding-bottom: 50px;
  padding-left: 80px;
}
</style>
<body style="background-color:DodgerBlue;">

<?php
echo '<br>';
echo '<center><h1 style="color:Maroon;">Hello Iron Man</h1></center>';
echo '<center>You can see that I was having a chat with CloudVis but he did not recognize me</center><br>';
echo '<center>He wants something but I am not getting what</center><br>';
echo '<center><img src="chat.PNG" alt="Snow" style="width:40%"></center>';

if ($_GET[id] == 1 || $_GET[id] == 2)
{
	echo '<br><br>';
	echo '<p><b>No this is not the right no try again !!<b></p>';
}
elseif ($_GET[id] == 3)
{
	echo '<br><br>';
	echo '<p><b>Umm no try again mannn, !!<b></p><br>';
	echo '<p><b>Okay wait then what about zweihundertzwölf<b></p>';
}
elseif ($_GET[id] == 212)
{
	echo '<br><br>';
	echo '<center><p><b>You gave me the right id Number<b></p></center>';
	echo '<center><p><b>Now decode the code to get the password<b></p></center>';
	include('php_content.html');
	echo '<br>';
}
?>

</body>
</html>

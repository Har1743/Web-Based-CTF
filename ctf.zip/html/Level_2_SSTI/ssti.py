from flask import Flask, request, render_template_string, render_template

app = Flask(__name__)

app.secret_key = "CloudSEK{Let's move on to another /passive now}"


@app.route("/")
def index():
    search = request.args.get('search') or None

    template = '''
            <h1 style="text-align:center; color:red; margin-top:50px;"> IronMan you are too good, I bet you cannot get the 2nd Key</h1>
            <center><img src="/static/images/CloudSEK_logo.png" style="width:500px; padding-top:50px;"></center>
            <h2 style="text-align:center; color:green;padding-top:50px;">Hint:<i>CloudVis Server is using its capability for the processing of data you are sending to it...</i></h2>
	    <center><img src="/static/images/giphy.gif" style="width:250px; padding-top:20px;"></center>
            {}
    '''   .format(search)
    return render_template_string(template)



@app.route('/admin')
def admin():
    return "You got into wrong page try Harder..."


@app.route("/passive")
def passive():
    return render_template('passive.html')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)

<html>
<body>

<?php

session_start();

if (isset($_SESSION["user"]) && $_SESSION["user"] == "Cloudster")
{
	$user = $_SESSION["user"];
	echo "<html>";
	echo "<body style='background-color:DodgerBlue'>";
	echo "<br>";
	echo "<h1 style='text-align:center;color:red'>Hi IronMan" . "</h1>";
	echo "<h2 style='text-align:center;color:red'>You managed to come closer to my first key -- I am impressed" . "</h2>";
	echo "<center>" . "<img src='flaeegg.png' alt='Trulli' width='700' height='300'>" . "</center>";
	echo "<p style='text-align:center'><b>Jarvis was a very small project<b></p>";
	echo "<p style='text-align:center'><b>Not many functionalites were embeded in that<b></p>";
	echo "<p style='text-align:center'><b>But I am CloudVis you will not get easily in me what you desire for<b></p>";
	echo "</body>";
	echo "</html>";
}
else
{
	echo "<p>You are not authorised to view this page</p>";
}
?>
</body>
</html>
